# Backers

You can join them in supporting vue-i18n development by [pledging on Patreon](https://www.patreon.com/kazupon)! Backers in the same pledge level appear in the order of pledge date.

<h2 align="center">Gold Sponsors</h2>

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?c=1597144&patAmt=500.0)

<h2 align="center">Sliver Sponsors</h2>

<p align="center">
  <a href="https://www.codeandweb.com/babeledit?utm_campaign=vue-i18n-2019-01" target="_blank">
    <img src="https://raw.githubusercontent.com/kazupon/vue-i18n/dev/vuepress/.vuepress/public/patrons/babeledit.png">
  </a>
</p>

[It could be you!](https://www.patreon.com/bePatron?c=1597144&patAmt=250.0)

<h2 align="center">Bronze Sponsors</h2>

- Kazuyuki Miyake

[It could be you!](https://www.patreon.com/bePatron?c=1597144&patAmt=100.0)

<h2 align="center">Generous Supporters</h2>

[Currently vacant. It could be you!](https://www.patreon.com/bePatron?c=1597144&patAmt=50.0)

<h2 align="center">Awesome Supporters</h2>

- Shinya Katayama
- 38elements
- Fedor Indutny

[It could be you!](https://www.patreon.com/bePatron?c=1597144&patAmt=20.0)
