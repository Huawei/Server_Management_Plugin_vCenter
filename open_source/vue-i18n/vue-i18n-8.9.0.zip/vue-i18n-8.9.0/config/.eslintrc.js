module.exports = {
  globals: {
    process: true
  },
  extends: 'vue',
  rules: {
    'no-multiple-empty-lines': [2, {max: 2}],
    'no-console': 0
  }
}