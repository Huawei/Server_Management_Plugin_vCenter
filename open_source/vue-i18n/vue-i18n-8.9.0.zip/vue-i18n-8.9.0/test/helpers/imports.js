import assert from 'assert'
import sinon from 'sinon'

window.assert = assert
window.sinon = sinon
