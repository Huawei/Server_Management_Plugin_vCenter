# vue-i18n for contentful

> Example for Contentful integration

## Setup

### Setup contentful with tutorial
https://www.contentful.com/developers/docs/tutorials/general/get-started/

### Run
```
$ npm run dev
```

## License

MIT
