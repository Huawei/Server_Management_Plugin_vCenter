# vue-i18n-extensions-module-using-example-for-rollup

> vue-i18n-extentions module using example for rollup

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:5000
npm run dev

# build for production
npm run build
```

For detailed explanation on how things work, consult the [docs for rollup-plugin-vue](http://vuejs.github.io/rollup-plugin-vue/#/en/2.3/)
