<template>
  <div id="app">
    <h1>{{ $t('hello') }}</h1>
  </div>
</template>

<style>
h1 {
  color: #42b983;
}
</style>
